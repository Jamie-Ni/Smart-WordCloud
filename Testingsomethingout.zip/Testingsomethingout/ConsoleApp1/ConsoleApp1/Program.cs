﻿using System;
using System.Collections.Generic;

using System.Linq;

using System.Text;

using System.Data;
using System.Data.SqlClient;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            SqlConnection con;

            SqlDataReader reader;

            try

            {

                int id;

                con = new SqlConnection(Properties.Settings.Default.connectionStr);

                con.Open();

                Console.WriteLine("Enter Employee Id");

                id = int.Parse(Console.ReadLine());

                reader = new SqlCommand("select * from testReviewTable").ExecuteReader();



                if (reader.HasRows)

                {

                    while (reader.Read())

                    {

                        Console.WriteLine("EmpID | EmpName | EmpSalary \n {0}  |   {1}  |   {2}", reader.GetInt32(0),

                        reader.GetString(1), reader.GetInt32(2));

                    }

                }

                else

                {

                    Console.WriteLine("No rows found.");

                }

                reader.Close();

            }

            catch (Exception ex)

            {

                Console.WriteLine(ex.Message);

            }
            Console.WriteLine("Hello World!");
            Console.ReadKey(true);
        }
    }
}
