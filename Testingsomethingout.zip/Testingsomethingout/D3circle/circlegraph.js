var dataset = {
    apples: [53245, 28479, 19697, 24037, 40245],
    oranges: [53, 28, 19, 24],
    lemons: [53245, 28479, 19697, 24037, 40245],
    pears: [53245, 28479, 19697, 24037, 40245],
    pineapples: [53245, 28479, 19697, 24037, 40245],
};

var width = 460,
    height = 300,
    cwidth = 25;

var color = d3.scale.category20();

var pie = d3.layout.pie()
    .sort(null);

var arc = d3.svg.arc();

var svg = d3.select("#chart").append("svg")
    .attr("width", width)
    .attr("height", height)
    .append("g")
    .attr("transform", "translate(" + width / 2 + "," + height / 2 + ")");


    var gs = svg.selectAll("g").data(d3.values(dataset)).enter().append("g");
    var path = gs.selectAll("path")
        .data(function (d) { return pie(d); })
        .enter().append("path")
        .attr("fill", function (d, i) { return color(i); })
        .attr("d", function (d, i, j) { return arc.innerRadius(10 + cwidth * j).outerRadius(cwidth * (j + 1))(d); });









//just random data that I came up with
var donutGraphData = [
    {name:"Total Rooms Revenue", beneficial: 'True', compareData:110743819074,actualData:37819048104}/*,
    { name: "Total Room Occupied", beneficial: 'True', compareData: 78310473801, actualData: 164378916347},
    { name: "Total Hotel Expense", beneficial: 'False', compareData: 83190473, actualData: 6371496},
    { name: "Total Sales Revenue", beneficial: 'True', compareData: 3104783107438, actualData: 31478331743714},
    { name: "Total Labor Expense", beneficial: 'False', compareData: 31478390174893, actualData: 418374903718493}*/
];
//this turns the objects in the array to string form so you can see in the browser
for (stuff in donutGraphData) {
    document.write(stuff, '= ', JSON.stringify(donutGraphData[stuff]) + "<br/>");
}

/*
function MultiGaugeInit(widgetid, obj, params) {
    if (params['Count'] == undefined)
        params['Count'] = 1;

    if (!params['Configured'])
        return;
    else {
        for (var i = 0; i < params['Count']; i++) {
            let color, angle;
            if (obj.Variance[i].Class == "CPOS")
                color = "#60bd68";
            else if (obj.Variance[i].Class == "CNEG")
                color = "#f15854";
            else
                color = "#003F64";

            let valuedecimals = obj.Data[i].Rounding;
            let value = obj.Data[i].Value;
            let decimals = Math.log(value) / Math.LN10;
            let maxval = Math.pow(10, Math.ceil(decimals));
            let rounding = Math.floor(Math.log(maxval / value) / Math.LN2);
            if (rounding > 0) maxval = maxval / Math.pow(2, rounding);

            angle = Math.PI / 2 * (value / maxval);

            var arc = d3.arc()
                .innerRadius(50)
                .outerRadius(100)
                .startAngle(-Math.PI / 2)

            // Place svg element
            var svg = d3.select("#widget" + widgetid + " #Gauge" + i.toString())
                .append("g")
                .attr("transform", "translate(100,120)");

            // Append background arc to svg
            var background = svg.append("path")
                .datum({
                    endAngle: Math.PI / 2
                })
                .attr("fill", "#ddd")
                .attr("d", arc);

            var foreground = svg.append("path")
                .datum({
                    endAngle: angle
                })
                .attr("fill", color)
                .attr("fill-opacity", 0.75)
                .attr("d", arc);

            // Display Max value
            var max = svg.append("text")
                .attr("transform", "translate(75,15)")
                .attr("text-anchor", "middle")
                .attr("fill", "#aaa")
                .text(FormatValues(maxval, valuedecimals))

            // Display Min value
            var min = svg.append("text")
                .attr("transform", "translate(-75,15)")
                .attr("text-anchor", "middle")
                .attr("fill", "#aaa")
                .text("0")

            // Display Current value  
            var current = svg.append("text")
                .attr("transform", "translate(0,0)")
                .attr("text-anchor", "middle")
                .style("font-size", "18px")
                .style("font-weight", "bold")
                .text(FormatValues(value, valuedecimals))
        }
    }
}
*/